<?php
// Heading
$_['heading_title']       = 'Filtrai'; 

// Text
$_['text_module']         = 'Moduliai';
$_['text_success']        = 'Jūs sėkmingai atnaujinote filtrų modulį!';
$_['text_content_top']    = 'Turinio viršus';
$_['text_content_bottom'] = 'Turinio apačia';
$_['text_column_left']    = 'Kairys stulpelis';
$_['text_column_right']   = 'Dešinys stulpelis';

// Entry
$_['entry_layout']        = 'Išdėstymas:';
$_['entry_position']      = 'Pozicija:';
$_['entry_status']        = 'Statusas:';
$_['entry_sort_order']    = 'Rikiavimo eiliškumas:';

// Error
$_['error_permission']    = 'Dėmesio, jūs neturite teisių koreguoti filtrų modulio!';
?>