<?php
// Heading
$_['heading_title']    = 'Kategorijos';

// Text
$_['text_module']      = 'Moduliai';
$_['text_success']     = 'Jūs sėkmingai modifikavote Kategorijos modulį!';
$_['text_column_left'] = 'Kairėje';
$_['text_column_right']       = 'Dešinėje';
$_['text_content_top']    = 'Viršuje';
$_['text_content_bottom'] = 'Apačioje';

// Entry
$_['entry_layout']        = 'Išdėstymas:';
$_['entry_position']   = 'Pozicija:';
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti Kategorijos modulį!';
?>