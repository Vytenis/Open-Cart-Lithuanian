<?php
// Heading
$_['heading_title']    = 'Blokuoti pirkėjo IP';

// Text
$_['text_success']     = 'Jūs sėkmingai atnaujinote blokuojamus pirkėjų IP!';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Pirkėjai';
$_['column_action']    = 'Veiksmas';

// Entry
$_['entry_ip']         = 'IP:';

// Error
$_['error_permission'] = 'Dėmesio, jūs neturite teisių redaguoti blokuojamų pirkėjų IP!';
$_['error_ip']         = 'IP turi būti nuo 1 iki 15 simbolių ilgio!';
?>