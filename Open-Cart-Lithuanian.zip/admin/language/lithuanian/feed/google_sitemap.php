<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text   
$_['text_feed']        = 'Produkto sklaidos';
$_['text_success']     = 'Sėkmingai modifikavote Google Sitemap sklaidą!';

// Entry
$_['entry_status']     = 'Būsena:';
$_['entry_data_feed']  = 'Duomenų sklaidos Url:';

// Error
$_['error_permission'] = 'Jūs neturite teisės modifikuoti Google Sitemap sklaidą!';
?>