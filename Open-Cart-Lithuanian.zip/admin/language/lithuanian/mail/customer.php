<?php
// Text
$_['text_approve_subject']  = '%s - Jūsų paskyra aktyvuota!';
$_['text_approve_welcome']  = 'Ačiū, kad prisiregistravote el. parduotuvėje %s!';
$_['text_approve_login']    = 'Jūsų paskyra sukurta ir Jūs galite prisijungti su savo el. pašto adresu ir slaptažodžiu šiuo adresu:';
$_['text_approve_services'] = 'Prisijungę, galėsite susipažinti su įvairiomis paslaugomis: peržiūrėti paskutinius užsakymus, spausdinti sąskaitas faktūras ir redaguoti savo sąskaitos informaciją.';
$_['text_approve_thanks']   = 'Ačiū,';
$_['text_transaction_subject']  = '%s - Paskyros kreditas';
$_['text_transaction_received'] = 'Jūs gavote %s kredit-ų/s!';
$_['text_transaction_total']    = 'Viso kreditų %s.' . "\n\n" . 'Kreditai bus automatiškai sumažinti kitame Jūsų užsakyme.';
$_['text_reward_subject']       = '%s - Bonus taškai';
$_['text_reward_received']      = 'Gavote %s bonus taškų!';
$_['text_reward_total']         = 'Sukaupta taškų %s.';
?>