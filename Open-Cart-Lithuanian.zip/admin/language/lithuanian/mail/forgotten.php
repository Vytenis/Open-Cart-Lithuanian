<?php
// Text
$_['text_subject']  = '%s - slaptažodžio keitimo užklausa';
$_['text_greeting'] = 'Inicijuotas %s administratoriaus slaptažodžio keitimas.';
$_['text_change']   = 'Norėdami pakeisti slaptažodį, paspauskite žemiau esančią nuorodą:';
$_['text_ip']       = 'Užklausa siųsta iš %s IP adreso';
?>