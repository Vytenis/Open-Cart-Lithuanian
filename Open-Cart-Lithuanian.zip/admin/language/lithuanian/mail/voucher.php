<?php
// Text
$_['text_subject']  = '%s Jums atsiuntė dovanų kuponą';
$_['text_greeting'] = 'Sveikiname, jums atsiųsto dovanų kupono vertė yra %s';
$_['text_from']     = 'Šis dovanų kuponas buvo atsiųsta jums nuo %s';
$_['text_message']  = 'Su žinute';
$_['text_redeem']   = 'Norėdami panaudoti dpovanų kuponą, užsirašykite šį kupono kodą: <b>%s</b> tada paspauskite nuorodą, esančią žemiau ir įsigykite norimas prekes. Dovanų kupono kodą reikės įvesti užsakymo formavimo žingsnių metu prieš užbaigiant užsakymą.';
$_['text_footer']   = 'Jei turite klausimų, atsakykite į šį laišką.';
?>