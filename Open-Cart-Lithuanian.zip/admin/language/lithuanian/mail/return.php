<?php
// Text
$_['text_subject']       = '%s - grąžinimo atnaujinmas %s';
$_['text_return_id']     = 'Grąžinimo ID:';
$_['text_date_added']    = 'Grąžinimo data:';
$_['text_return_status'] = 'Jūsų grąžinimo naujasis statusas:';
$_['text_comment']       = 'Komentarai:';
$_['text_footer']        = 'Jei turite klausimų, atsakykite į šį laišką.';
?>