<?php
// Text
$_['text_approve_subject']      = '%s - Jūsų paskyra aktyvuota!';
$_['text_approve_welcome']      = 'Sveiki prisijungę %s!';
$_['text_approve_login']        = 'Jūsų paskyra sukurta, dabar galite prisijungti naudodami el. pašto adresą ir slaptažodį šiuo adresu:';
$_['text_approve_services']     = 'Prisijungę Jūs galėsite generuoti sekimo kodus, sekti komisinius pervedimus ir redaguoti savo paskyros informaciją.';
$_['text_approve_thanks']       = 'Dėkojame,';
$_['text_transaction_subject']  = '%s - Partnerių komisiniai';
$_['text_transaction_received'] = 'Jūs gavote %s komisinių!';
$_['text_transaction_total']    = 'Sukaupti komisiniai %s.';
?>