<?php
// Heading
$_['heading_title'] = 'Priėjimas uždraustas!'; 

// Text
$_['text_permission'] = 'Jūs neturite teisių pasiekti šį puslapį, susisiekite su administratorium.';
?>
