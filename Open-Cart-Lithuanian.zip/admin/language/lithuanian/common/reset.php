<?php
// header
$_['heading_title']  = 'Slaptažodžio keitimas';

// Text
$_['text_reset']     = 'Pakeiskite savo slaptažodį!';
$_['text_password']  = 'Įveskite pageidaujamą slaptažodį.';
$_['text_success']   = 'Slaptažodis atnaujintas sėkmingai.';

// Entry
$_['entry_password'] = 'Slaptažodis:';
$_['entry_confirm']  = 'Pakartoti slaptažodį:';

// Error
$_['error_password'] = 'Slaptažodis turi būti nuo 5 iki 20 simbolių ilgio!';
$_['error_confirm']  = 'Slaptažodis ir jo pakartojimas nesutampa!';
?>