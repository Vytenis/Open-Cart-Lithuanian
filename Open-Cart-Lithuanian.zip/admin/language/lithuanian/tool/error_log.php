<?php
// Heading
$_['heading_title'] = 'Klaidų žurnalas';

// Text
$_['text_success']  = 'Jūs sėkmingai išvalėte klaidų žurnalą!';
?>