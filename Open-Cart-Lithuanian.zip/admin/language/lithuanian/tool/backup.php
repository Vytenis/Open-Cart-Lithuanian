<?php
// Heading
$_['heading_title']    = 'Kopijuoti/Atstatyti';

// Text
$_['text_backup']      = 'Parsiųsti atsarginę kopiją';
$_['text_success']     = 'Jūs sėkmingai importavotes savo DB!';

// Entry
$_['entry_restore']    = 'Atstatyti iš atsarginės kopijos:';
$_['entry_backup']     = 'Atstatyti:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti atsarginių kopijų!';
$_['error_backup']     = 'Dėmesio: Jūs turite pasirinkti bent vieną lentelę atsarginei kopijai atlikti!';
$_['error_empty']      = 'Įkeltas failas tuščias!';
?>