<?php
// Heading
$_['heading_title']    = 'Svoriu paremtas pristatymas';

// Text
$_['text_shipping']    = 'Pristatymas';
$_['text_success']     = 'Success: You have modified weight based shipping!';

// Entry
$_['entry_rate']       = '�kainiai:<br /><span class="help">Pavydys: 5:10.00,7:12.00 Svoris:Kaina,Svoris:Kaina, t.t.</span>';
$_['entry_tax_class']        = 'Mokes�i� klas�:';
$_['entry_geo_zone']   = 'Geo zona:';
$_['entry_status']     = 'Statusas:';
$_['entry_sort_order'] = 'Eili�kumas:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify weight based shipping!';
?>