<?php
// Heading
$_['heading_title']    = 'Fiksuotas mokestis';

// Text
$_['text_shipping']    = 'Pristatymas';
$_['text_success']     = 'Jūs sėkmingai modifikavote fiksuotą pristatymo mokestį!';

// Entry
$_['entry_cost']       = 'Kaina:';
$_['entry_tax_class']        = 'Mokesčių klasė:';
$_['entry_geo_zone']   = 'Geo zona:';
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti fiksuotą pristatymo mokestį!';
?>