<?php
// Heading
$_['heading_title']     = 'Kiekvienos prekės atskirai';

// Text
$_['text_shipping']    = 'Pristatymas';
$_['text_success']     = 'Jūs sėkmingai modifikavote kiekvienos prekės atskirai pristatymo nustatymus!';

// Entry
$_['entry_cost']       = 'Kaina:';
$_['entry_tax_class']        = 'Mokesčių klasė:';
$_['entry_geo_zone']   = 'Geo zona:';
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti kiekvienos prekės atskirai pristatymo nustatymus!';
?>