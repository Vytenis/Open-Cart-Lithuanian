<?php
// Heading
$_['heading_title']      = 'Nemokamas';

// Text
$_['text_payment']       = 'Apmokėjimas';
$_['text_success']       = 'Redagavimas sėkmingas!';

// Entry
$_['entry_order_status'] = 'Užsakymo būsena:';
$_['entry_status']       = 'Būsena:';
$_['entry_sort_order']   = 'Rikiavimo eiliškumas:';

// Error
$_['error_permission']   = 'Dėmesio: Jūs neturite teisių redaguoti Nemokamas!';
?>