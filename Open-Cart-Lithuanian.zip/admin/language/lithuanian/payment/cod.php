<?php
// Heading
$_['heading_title']      = 'Grynais pristatymo metu';

// Text
$_['text_payment']       = 'Apmokėjimas';
$_['text_success']       = 'Jūs sėkmingai modifikavote apmokėjimo grynais pristatymo metu modulį!';

// Entry
$_['entry_order_status'] = 'Užsakymo būsena:';
$_['entry_geo_zone']     = 'Geo zona:';
$_['entry_status']       = 'Būsena:';
$_['entry_sort_order']   = 'Rūšiavimo tvarka:';
$_['entry_total']        = 'Viso:<br /><span class="help">Suma nuo kurios šis apmokėjimo būdas tampa aktyvus.</span>';

// Error
$_['error_permission']   = 'Jūs neturite teisių modifikuoti apmokėjimo grynais pristatymo metu!';
?>