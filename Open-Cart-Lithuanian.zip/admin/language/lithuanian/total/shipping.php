<?php
// Heading
$_['heading_title']    = 'Pristatymas';

// Text
$_['text_total']       = 'Užsakymo suma';
$_['text_success']     = 'Jūs sėkmingai modifikavote pristatymo sumą!';

// Entry
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rūšiavimo eiliškumas:';
$_['entry_estimator']  = 'Pristatymo prognozė:';

// Error
$_['error_permission'] = 'Jūs neturite teisių modifikuoti pristatymo sumą!';
?>