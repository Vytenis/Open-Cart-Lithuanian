<?php
// Heading
$_['heading_title']    = 'Bonus taškai';

// Text
$_['text_total']       = 'Užsakymų suma';
$_['text_success']     = 'Redagavimas sėkmingas!';

// Entry
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rikiavimas:';

// Error
$_['error_permission'] = 'Dėmesio: Jūs neturite teisių redaguoti bonus taškų!';
?>