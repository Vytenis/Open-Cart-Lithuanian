<?php
// Heading
$_['heading_title']    = 'Supakavimo mokestis';

// Text
$_['text_total']       = 'Užsakymo suma';
$_['text_success']     = 'Redagavimas sėkmingas!';

// Entry
$_['entry_total']       = 'Užsakymo suma';
$_['entry_fee']        = 'Mokestis:';
$_['entry_tax_class']        = 'Mokesčių klasė:';
$_['entry_status']     = 'Būsena:';
$_['entry_sort_order'] = 'Rikiavimas:';

// Error
$_['error_permission'] = 'Dėmesio: Jūs neturite teisių redaguoti supakavimo mokestį!';
?>