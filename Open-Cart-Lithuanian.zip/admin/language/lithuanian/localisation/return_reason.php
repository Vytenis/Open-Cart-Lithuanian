<?php
// Heading
$_['heading_title']    = 'Grąžinimo priežastys';

// Text
$_['text_success']     = 'Grąžinimo priežastys atnaujintos sėkmingai!';

// Column
$_['column_name']      = 'Pavadinimas';
$_['column_action']    = 'Veiksmas';

// Entry
$_['entry_name']       = 'Pavadinimas:';

// Error
$_['error_permission'] = 'Dėmesio: Neturite teisių redaguoti grąžinimo priežastis!';
$_['error_name']       = 'Pavadinimas turi turėti nuo 3 iki 32 simbolių!';
$_['error_return']     = 'Dėmesio: Ši būsena negali būti pašalinta, nes yra priskirta grąžintoms prekėms!';
?>