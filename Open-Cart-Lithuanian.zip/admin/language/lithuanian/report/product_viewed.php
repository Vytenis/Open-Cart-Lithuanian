<?php
// Heading
$_['heading_title']  = 'Peržiūrėtų prekių ataskaita';

// Text
$_['text_success']   = 'Ataskaita sėkmingai paleista iš naujo!';

// Column
$_['column_name']    = 'Prekės pavadinimas';
$_['column_model']   = 'Modelis';
$_['column_viewed']  = 'Peržiūrėta';
$_['column_percent'] = 'Procentai';
?>