<?php
// Heading
$_['heading_title']         = 'Pirkėjų užsakymų ataskaita';

// Text
$_['text_all_status']       = 'Visos būsenos';

// Column
$_['column_customer']       = 'Pirkėjas';
$_['column_email']          = 'El. paštas';
$_['column_customer_group'] = 'Pirkėjų grupė';
$_['column_status']         = 'Būsena';
$_['column_orders']         = 'Užsakymų kiekis';
$_['column_products']       = 'Prekių kiekis';
$_['column_total']          = 'Viso';
$_['column_action']         = 'Veiksmas';

// Entry
$_['entry_date_start']      = 'Pradžia:';
$_['entry_date_end']        = 'Pabaiga:';
$_['entry_status']          = 'Užsakymo būsena:';
?>