<?php
// Heading
$_['heading_title']     = 'Komisinių ataskaita';

// Column
$_['column_affiliate']  = 'Pavadinimas';
$_['column_email']      = 'El. paštas';
$_['column_status']     = 'Būsena';
$_['column_commission'] = 'Komisiniai';
$_['column_orders']     = 'Užsakymų kiekis';
$_['column_total']      = 'Viso';
$_['column_action']     = 'Veiksmas';

// Entry
$_['entry_date_start']  = 'Pradžia:';
$_['entry_date_end']    = 'Pabaiga:';
?>