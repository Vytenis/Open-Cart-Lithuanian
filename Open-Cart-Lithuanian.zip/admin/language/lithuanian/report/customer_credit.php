<?php
// Heading
$_['heading_title']         = 'Pirkėjų kreditų ataskaita';

// Column
$_['column_customer']       = 'Pirkėjas';
$_['column_email']          = 'El. paštas';
$_['column_customer_group'] = 'Pirkėjų grupė';
$_['column_status']         = 'Būsena';
$_['column_total']          = 'Viso';
$_['column_action']         = 'Veiksmas';

// Entry
$_['entry_date_start']      = 'Pradžia:';
$_['entry_date_end']        = 'Pabaiga:';
?>