<?php
// Heading
$_['heading_title']     = 'Prisijungusių pirkėjų ataskaita';

// Text 
$_['text_guest']        = 'Svečias';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Pirkėjas';
$_['column_url']        = 'Paskutinis aplankytas puslapis';
$_['column_referer']    = 'Šaltinis';
$_['column_date_added'] = 'Paskutinis paspaudimas';
$_['column_action']     = 'Veiksmas';
?>