<?php
// Heading
$_['heading_title']     = 'Moduliai';

// Text
$_['text_install']      = 'Įdiegti';
$_['text_uninstall']    = 'Pašalinti';

// Column
$_['column_name']       = 'Modulio pavadinimas';
$_['column_action']     = 'Veiksmas';

// Error
$_['error_permission']  = 'Jūs neturite teisės modifikuoti modulius!';
?>