<?php
// Heading 
$_['heading_title']    = 'Duomenų sklaida';

// Text
$_['text_install']     = 'Įdiegti';
$_['text_uninstall']   = 'Išdiegti';

// Column
$_['column_name']      = 'Sklaidos pavadinimas';
$_['column_status']    = 'Būsena';
$_['column_action']    = 'Veiksmas';

// Error
$_['error_permission'] = 'Dėmėsio: Jūs neturite teisių redaguoti duomenų sklaida!';
?>