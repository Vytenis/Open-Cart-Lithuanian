<?php
// Heading 
$_['heading_title']    = 'Plėtinių valdymas';

// Text
$_['text_success']     = 'Jūs sėkmingai instaliavote plėtinį!';

// Error
$_['error_permission'] = 'Jūs neturite teisių atlikti pakeitimus plėtinių valdyme!';
$_['error_upload']     = 'Įkėlimas reikalingas!';
$_['error_filetype']   = 'Negalimas bylos tipas!';
?>