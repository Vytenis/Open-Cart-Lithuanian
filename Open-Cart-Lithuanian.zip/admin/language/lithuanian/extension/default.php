<?php
$_['lang_openbay_new']              = 'Sukurti naujas prekes';
$_['lang_openbay_edit']             = 'Peržiūrėti / redaguoti prekes';
$_['lang_openbay_fix']              = 'Taisyti klaidas';
$_['lang_openbay_processing']       = 'Vykdoma';

$_['lang_amazonus_saved']           = 'Išsaugota (neįkelta)';
$_['lang_amazon_saved']             = 'Išsaugota (neįkelta)';
$_['lang_play_pending_new']         = 'Laukia (nauja)';
$_['lang_play_pending_updated']     = 'Laukia (atnaujinta)';
$_['lang_play_warning']             = 'Perspėjimo pranešimas';
$_['lang_play_pending_delete']      = 'Laukia trynimo';
$_['lang_play_stock_updating']      = 'Sandėlys atnaujinamas';

$_['lang_markets']                  = 'Rinkos';
$_['lang_bulk_btn']                 = 'eBay masinis įkėlimas';

$_['lang_marketplace']              = 'Atvira rinka';
$_['lang_status']                   = 'Statusas';
$_['lang_option']                   = 'Opcija';
?>