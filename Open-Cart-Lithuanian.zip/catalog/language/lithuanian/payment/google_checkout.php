<?php
// Entry
$_['text_title']     = 'Kreditinė kortelė / Debetinė kortelė (Google Checkout)';

// Error
$_['error_shipping'] = 'Dėmesio: Pristatymo būdas yra privalomas!';
?>