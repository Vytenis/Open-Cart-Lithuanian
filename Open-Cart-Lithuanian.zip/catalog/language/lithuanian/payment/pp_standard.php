<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_reason'] 	= 'Paskirtis';
$_['text_testmode']	= 'Perspėjimas: Mokėjimų agregatorius yra \'Smėlio dėžės\' režie. Jūsų paskyra nebus apmokestinta.';
$_['text_total']	= 'Pristatymas, aptarnavimas, nuolaida ir mokesčiai';
?>