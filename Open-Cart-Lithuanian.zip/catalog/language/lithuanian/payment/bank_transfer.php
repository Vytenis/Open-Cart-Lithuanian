<?php
// Text
$_['text_title']       = 'Banko pavedimu';
$_['text_instruction'] = '<b>Žemiau pateikti rekvizitai banko apmokėjimui:</b>';
$_['text_description'] = 'Perveskite viso sumą į nurodytą banko sąskaita.';
$_['text_payment']     = 'Mokėdami pavedimu mokėjimo paskirties laukelyje įrašykite užsakymo numerį.</br>Sąskaita faktūra bus išsiųsta kartus su prekėmis.</br>Neapmokėjus už prekes per 48 val. prekių rezervacija atšaukiama, užsakymas anuliuojams.';
?>