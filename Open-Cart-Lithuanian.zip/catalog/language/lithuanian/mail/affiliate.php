<?php
// Text
$_['text_subject']  = '%s - Partnerių programa';
$_['text_welcome']  = 'Dėkojame prisijungus prie %s partnerių programos!';
$_['text_approval'] = 'Your account must be approved before you can login. Once approved you can log in by using your email address and password by visiting our website or at the following URL:';
$_['text_services'] = 'Upon logging in, you will be able to generate tracking codes, track commission payments and edit your account information.';
$_['text_thanks']   = 'Dėkojame,';
?>