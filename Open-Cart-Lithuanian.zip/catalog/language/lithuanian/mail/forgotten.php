<?php
// Text
$_['text_subject']  = '%s - Naujas slaptažodis';
$_['text_greeting'] = 'Naujo slaptažodžio paprašė: %s.';
$_['text_password'] = 'Jūsų naujas slaptažodis:';
?>