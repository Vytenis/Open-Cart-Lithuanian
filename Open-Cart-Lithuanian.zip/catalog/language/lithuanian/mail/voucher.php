<?php
// Text
$_['text_subject']  = '%s jums siunčia dovanų čekį';
$_['text_greeting'] = 'Sveikiname, Jūs gavote dovanų čekį, kurio vertė yra %s';
$_['text_from']     = 'Šį dovanų kuponą jums atsiuntė %s';
$_['text_message']  = 'Palikta žinutė';
$_['text_redeem']   = 'Norėdami panaudoti dovanų čekį, užsirašykite šį kodą <b>%s</b> tada paspauskite nuorodą žemiau ir pradėkite dėti į krepšelį prekes, kurioms norėsite panaudoti dovanų čekį. Dovanų čekio kodą jums reikės įvesti prieš užsakymo užbaigimą.';
$_['text_footer']   = 'Jei turite klausimų, atsakykite į šį laišką.';
?>