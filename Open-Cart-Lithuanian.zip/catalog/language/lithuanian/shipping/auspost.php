<?php
// Text
$_['text_title']    = 'Australijos paštas';
$_['text_express']  = 'Greitasis';
$_['text_standard'] = 'Standartinis';
$_['text_eta']      = 'dienos';
?>