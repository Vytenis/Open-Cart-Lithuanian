<?php

// Text
$_['text_title']       = 'Už vienetą';
$_['text_description'] = 'Pristatymo kaina už vienetą';
?>