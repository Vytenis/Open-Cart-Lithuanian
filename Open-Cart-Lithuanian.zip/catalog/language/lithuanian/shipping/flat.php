<?php

// Text
$_['text_title']       = 'Fiksuota kaina';
$_['text_description'] = 'Fiksuota pristatymo kaina';
?>