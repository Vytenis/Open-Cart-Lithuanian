<?php

// Text
$_['text_title']       = 'Nemokamas siuntimas';
$_['text_description'] = 'Nemokamas siuntimas';
?>