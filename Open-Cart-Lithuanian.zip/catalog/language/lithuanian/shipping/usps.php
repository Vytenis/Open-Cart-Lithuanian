<?php

// Text
$_['text_title']  = 'JAV pašto tarnyba';
$_['text_weight'] = 'Svoris:';
$_['text_eta']    = 'Pristatymo laikas:';
?>