<?php
// Text
$_['text_title']  = 'Citylink';
$_['text_weight'] = 'Svoris:';
?>