<?php

// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Svoris:'; 
$_['text_insurance']   = 'Draudžiamas iki:';   
$_['text_time']        = 'Įvykdymo laikas: Per 48 valandas'; 
?>