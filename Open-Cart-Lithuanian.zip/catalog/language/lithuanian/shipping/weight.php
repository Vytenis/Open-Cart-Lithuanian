<?php
// Text
$_['text_title'] = 'Pristatymo kaina už siuntos svorį';
$_['text_weight'] = 'Svoris:'; 
?>