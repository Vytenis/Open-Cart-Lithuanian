<?php
// Opencart v1.4.9.3 Lithuanian transliation. UTF-8
// Opencart v1.3.2 Lithuanian by Saulius Varskevicius, varske@takas.lt
// Opencart v1.4.0 Lithuanian by Rimvydas Zubkus, rimasz@kava.lt
// Opencart v1.4.8b Lithuanian by Andrejus Zlotnikovas, andrejuszl@gmail.com
// Opencart v1.4.9.1 Lithuanian by Rimvydas Zubkus, rimasz@kava.lt
// Opencart v1.4.9.3 Lithuanian by Andrejus Zlotnikovas, andrejuszl@gmail.com
// Opencart v1.5.0 Lithuanian by Marius Radvilavicius radvis@gmail.com



// Text
$_['text_title']                = 'Karališkasis paštas';
$_['text_weight']               = 'Svoris:';
$_['text_insurance']            = 'Draudimas iki:';
$_['text_1st_class_standard']   = 'Pirmos klasės paprasta siunta';
$_['text_1st_class_recorded']   = 'Pirmos klasės registruota siunta';
$_['text_2nd_class_standard']   = 'Antros klasės paprasta siunta';
$_['text_2nd_class_recorded']   = 'Antros klasės registruota siunta';
$_['text_special_delivery_500']  = 'Specialus pristatymas sekančią dieną (&pound;500)';
$_['text_special_delivery_1000'] = 'Specialus pristatymas sekančią dieną (&pound;1000)';
$_['text_special_delivery_2500'] = 'Specialus pristatymas sekančią dieną (&pound;2500)';
$_['text_standard_parcels']     = 'Paprastos siuntos';
$_['text_airmail']              = 'Oro paštas';
$_['text_international_signed'] = 'Tarptautinis regstruotas paštas';
$_['text_airsure']              = 'Oro paštas';
$_['text_surface']              = 'Žemės paštas';
?>