<?php

// Text
$_['text_title']       = 'Pasiimti pačiam';
$_['text_description'] = 'Pasiėmimas iš parduotuvės';
?>