<?php
// Text
$_['text_title']                               = 'Fedex';
$_['text_weight']                              = 'Svoris:';
$_['text_eta']                                 = 'Planuojamas laikas:';
$_['text_europe_first_international_priority'] = 'Europa pirmenybinis tarptautinis';
$_['text_fedex_1_day_freight']                 = 'Fedex 1 Dienos Freight';
$_['text_fedex_2_day']                         = 'Fedex 2 Diena';
$_['text_fedex_2_day_am']                      = 'Fedex 2 Diena Ryte';
$_['text_fedex_2_day_freight']                 = 'Fedex 2 Dienos Freight';
$_['text_fedex_3_day_freight']                 = 'Fedex 3 Dienos Freight';
$_['text_fedex_express_saver']                 = 'Fedex Express Taupusis';
$_['text_fedex_first_freight']                 = 'Fedex Pirmas Fright';
$_['text_fedex_freight_economy']               = 'Fedex Fright ekonominis';
$_['text_fedex_freight_priority']              = 'Fedex Fright pirmenybinis';
$_['text_fedex_ground']                        = 'Fedex Žemė';
$_['text_first_overnight']                     = 'Pirmas Pernakt';
$_['text_ground_home_delivery']                = 'Ground Home Delivery';
$_['text_international_economy']               = 'Tarptautinis ekonominis';
$_['text_international_economy_freight']       = 'Tarptautinis ekonominis Freight';
$_['text_international_first']                 = 'Tarptautinis pirmas';
$_['text_international_priority']              = 'Tarptautinis pirmenybinis';
$_['text_international_priority_freight']      = 'Tarptautinis pirmenybinis Freight';
$_['text_priority_overnight']                  = 'Pirmenybinis Pernakt';
$_['text_smart_post']                          = 'Protingas pristatymas';
$_['text_standard_overnight']                  = 'Standartinis Pernakt';
?>