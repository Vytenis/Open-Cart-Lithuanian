<?php
// Heading 
$_['heading_title']    = 'Partnerių sekimas';

// Text
$_['text_account']     = 'Profilis';
$_['text_description'] = 'Siekdami užtikrinti jūsų uždarbį nuo atvestų lankytojų mes turime juos atsekti ir susieti per unikalią nuorodą. Ši nuoroda turės jūsų unikalų sekimo kodą. Toliau galite pasinaudoti įrankiu, generuojančiu sekimo kodus į %s el. parduotuvę.';
$_['text_code']        = '<b>Jūsų sekimo kodas:</b>';
$_['text_generator']   = '<b>Sekimo kodų generatorius</b><br />Įveskite pavadinimą produkto, į kurį norite nukreipti lankytojus:';
$_['text_link']        = '<b>Sekimo nuorodos:</b>';
?>