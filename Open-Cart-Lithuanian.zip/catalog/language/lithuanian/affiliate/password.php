<?php
// Heading 
$_['heading_title']  = 'Keisti slaptažodį';

// Text
$_['text_account']   = 'Profilis';
$_['text_password']  = 'Jūsų slaptažodis';
$_['text_success']   = 'Jūsų slaptažodis sėkmingai atnaujintas.';

// Entry
$_['entry_password'] = 'Slaptažodis:';
$_['entry_confirm']  = 'Pakartotas slaptažodis:';

// Error
$_['error_password'] = 'Slaptažodis turi būti nuo 4 iki 20 simbolių ilgio!';
$_['error_confirm']  = 'Nesutampa įvesti slaptažodžiai!';
?>