<?php
// Heading 
$_['heading_title'] = 'Atsijungti';

// Text
$_['text_message']  = '<p>Jūs atsijungėte nuo savo paskyros. Dabar saugu palikti kompiuterį be priežiūros.</p><p>Jūsų krepšelis išsaugotas ir ten esančios prekės bus atkurtos Jums prisijungus prie savo paskyros sekantį kartą.</p>';
$_['text_account']  = 'Paskyra';
$_['text_logout']   = 'Atsijungti';
?>