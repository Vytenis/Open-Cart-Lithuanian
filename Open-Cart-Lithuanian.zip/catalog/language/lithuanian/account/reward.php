<?php
// Heading 
$_['heading_title']      = 'Jūsų bičiulių taškai';

// Column
$_['column_date_added']  = 'Sukurta';
$_['column_description'] = 'Aprašymas';
$_['column_points']      = 'Taškai';

// Text
$_['text_account']       = 'Paskyra';
$_['text_reward']        = 'Bičiulių taškai';
$_['text_total']         = 'Jūsų turimi bičiulių taškai:';
$_['text_empty']         = 'Jūs neturite bičiulių taškų!';
?>