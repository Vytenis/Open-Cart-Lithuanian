<?php
// Heading 
$_['heading_title']      = 'Jūsų tranzakcijos';

// Column
$_['column_date_added']  = 'Sukurta';
$_['column_description'] = 'Aprašymas';
$_['column_amount']      = 'Kiekis (%s)';

// Text
$_['text_account']       = 'Paskyra';
$_['text_transaction']   = 'Jūsų tranzakcijos';
$_['text_total']         = 'Esamas balansas:';
$_['text_empty']         = 'Nėra tranzakcijų!';
?>