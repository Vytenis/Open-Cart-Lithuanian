<?php
// Heading 
$_['heading_title']  = 'Pakeisti slaptažodį';

// Text
$_['text_account']   = 'Paskyra';
$_['text_password']  = 'Jūsų slaptažodis';
$_['text_success']   = 'Pavyko: Jūsų slaptažodis sėkmingai atnaujintas.';

// Entry
$_['entry_password'] = 'Slaptažodis:';
$_['entry_confirm']  = 'Patvirtinkite slaptažodį:';

// Error
$_['error_password'] = 'Slaptaždis turi turėti nuo 3 iki 20 simbolių!';
$_['error_confirm']  = 'Slaptažodis ir jo patvirtinimas nesutampa!';
?>