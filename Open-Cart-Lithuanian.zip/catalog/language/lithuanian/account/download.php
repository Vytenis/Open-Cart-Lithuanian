<?php
// Heading 
$_['heading_title']   = 'Paskyros parsisiuntimai';

// Text
$_['text_account']    = 'Paskyra';
$_['text_downloads']  = 'Parsisiuntimai';
$_['text_order']      = 'Užsakymo ID:';
$_['text_date_added'] = 'Data:';
$_['text_name']       = 'Vardas:';
$_['text_remaining']  = 'Liko:';
$_['text_size']       = 'Dydis:';
$_['text_empty']      = 'Jūs neturite ankstesnių parsisiunčiamų užsakymų!';
?>