<?php
// Heading 
$_['heading_title']    = 'Naujienlaiškio prenumerata';

// Text
$_['text_account']     = 'Paskyra';
$_['text_newsletter']  = 'Naujienlaiškis';
$_['text_success']     = 'Pavyko: Jūsų naujienlaiškio prenumerata sėkmingai atnaujinta!';

// Entry
$_['entry_newsletter'] = 'Užsakyti:';
?>
