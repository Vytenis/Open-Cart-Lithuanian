<?php
// Heading
$_['heading_title'] = 'Ieškomas puslapis nerastas!';

// Text
$_['text_error']    = 'Ieškomas puslapis nerastas.';
?>