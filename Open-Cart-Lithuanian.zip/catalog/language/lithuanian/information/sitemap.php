<?php
// Heading
$_['heading_title']    = 'Parduotuvės žemėlapis';
 
// Text
$_['text_special']     = 'Specialūs pasiūlymai';
$_['text_account']     = 'Mano paskyra';
$_['text_edit']        = 'Paskyros informacija';
$_['text_password']    = 'Slaptažodis';
$_['text_address']     = 'Adresų knygelė';
$_['text_history']     = 'Užsakymų istorija';
$_['text_download']    = 'Parsisiuntimai';
$_['text_cart']        = 'Krepšelis';
$_['text_checkout']    = 'Atsiskaitymas';
$_['text_search']      = 'Paieška';
$_['text_information'] = 'Informacija';
$_['text_contact']     = 'Kontaktai';
?>
