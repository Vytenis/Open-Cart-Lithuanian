<?php
// Text
$_['text_error'] = 'Norimas puslapis nerastas!';
?>