<?php
// Text
$_['text_voucher']  = 'Čekis(%s):';

?>