<?php

// Text
$_['text_reward']   = 'Bičiulių taškai(%s):';
$_['text_order_id'] = 'Užsakymo Nr.: #%s';

?>