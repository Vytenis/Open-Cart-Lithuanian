<?php

$_['text_handling'] = 'Užsakymo aptarnavimo mokestis:';
?>