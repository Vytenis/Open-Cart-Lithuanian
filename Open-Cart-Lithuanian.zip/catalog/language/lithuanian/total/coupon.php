<?php
// Text
$_['text_coupon']   = 'Kuponas(%s):';

?>