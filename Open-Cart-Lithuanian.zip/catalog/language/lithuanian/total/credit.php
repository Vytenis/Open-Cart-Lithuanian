<?php

$_['text_credit']   = 'Parduotuvės kreditas:';
$_['text_order_id'] = 'Užsakymo Nr.: #%s';
?>