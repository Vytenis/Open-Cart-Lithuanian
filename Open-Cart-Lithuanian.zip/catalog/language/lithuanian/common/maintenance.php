<?php
// Heading
$_['heading_title']     = 'Tvarkymo darbai';

// Text
$_['text_maintenance']  = 'Tvarkymo darbai';
$_['text_message']      = '<h1 style="text-align:center;">Šiuo metu atliekami tvarkymo darbai. <br/>Svetainė pradės dirbti kaip tik galime greičiau. Prašome užsukti vėliau.</h1>';
?>