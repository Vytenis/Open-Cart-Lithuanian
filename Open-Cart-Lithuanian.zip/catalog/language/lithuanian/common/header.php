<?php
// Text
$_['text_home']     = 'Pradžia';
$_['text_wishlist'] = 'Norų sąrašas (%s)';
$_['text_shopping_cart']     = 'Krepšelis';
$_['text_search']   = 'Paieška';
$_['text_welcome']  = 'Sveiki, jūs galite <a href="%s">prisijungti</a> arba <a href="%s">registruotis</a>.';
$_['text_logged']   = 'Esate prisijungęs kaip <a href="%s">%s</a> <b>(</b> <a href="%s">Atsijungti</a> <b>)</b>';
$_['text_account']  = 'Paskyra';
$_['text_checkout'] = 'Atsiskaityti';
?>
