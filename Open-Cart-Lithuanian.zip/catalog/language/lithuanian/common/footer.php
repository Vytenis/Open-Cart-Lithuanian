<?php
// Text
$_['text_information']  = 'Informacija';
$_['text_service']      = 'Klientų aptarnavimas';
$_['text_extra']        = 'Papildomai';
$_['text_contact']      = 'Susisiekite';
$_['text_return']       = 'Grąžinimai';
$_['text_sitemap']      = 'Svetainės medis';
$_['text_manufacturer'] = 'Gamintojai';
$_['text_voucher']      = 'Dovanų kuponai';
$_['text_affiliate']    = 'Partneriai';
$_['text_special']      = 'Specialūs';
$_['text_account']      = 'Paskyra';
$_['text_order']        = 'Užsakymų istorija';
$_['text_wishlist']     = 'Norų sąrašas';
$_['text_newsletter']   = 'Naujienlaiškis';
$_['text_powered']      = 'Varikliukas <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
?>