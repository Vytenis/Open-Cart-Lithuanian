<?php
// Heading 
$_['heading_title']  = 'Naujausi';

// Text
$_['text_reviews']  = '%s atsiliepimai(-ų).'; 
?>