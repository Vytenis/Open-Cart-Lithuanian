<?php
// Heading 
$_['heading_title'] = 'Populiariausi';

// Text
$_['text_reviews']  = 'Remiantis %s įvertinimų(-ais).'; 
?>