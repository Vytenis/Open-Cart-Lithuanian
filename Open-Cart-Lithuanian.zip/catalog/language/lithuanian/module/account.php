<?php
// Heading 
$_['heading_title']    = 'Paskyra';

// Text
$_['text_register']    = 'Registracija';
$_['text_login']       = 'Prisijungti';
$_['text_logout']      = 'Atsijungti';
$_['text_forgotten']   = 'Pamiršau slaptažodį';
$_['text_account']     = 'Mano paskyra';
$_['text_edit']        = 'Redaguoti paskyrą';
$_['text_password']    = 'Slaptažodis';
$_['text_address']     = 'Naudojami adresai';
$_['text_wishlist']    = 'Atmintinė';
$_['text_order']       = 'Užsakymų istorija';
$_['text_download']    = 'Atsisiuntimai';
$_['text_return']      = 'Grąžinimai';
$_['text_transaction'] = 'Tranzakcijos';
$_['text_newsletter']  = 'Naujienlaiškis';
$_['text_recurring']   = 'Pasikartojantys mokėjimai';
?>
