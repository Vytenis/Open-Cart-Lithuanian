<?php
$_['heading_title'] = 'Sveiki apsilankę %s';
?>