<?php
// Heading 
$_['heading_title']    = 'Partnerystės programa';

// Text
$_['text_register']    = 'Registruotis';
$_['text_login']       = 'Prisijungti';
$_['text_logout']      = 'Atsijungti';
$_['text_forgotten']   = 'Pamiršau slaptažodį';
$_['text_account']     = 'Mano paskyra';
$_['text_edit']        = 'Redaguoti paskyrą';
$_['text_password']    = 'Slaptažodis';
$_['text_payment']     = 'Mokėjimo opcijos';
$_['text_tracking']    = 'Referalų veiksmų žurnalas';
$_['text_transaction'] = 'Tranzakcijos';
?>
