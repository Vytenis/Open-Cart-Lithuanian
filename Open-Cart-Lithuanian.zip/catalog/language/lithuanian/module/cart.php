<?php
// Heading 
$_['heading_title']    = 'Krepšelis';

// Text
$_['text_cart']     = 'Krepšelis';
$_['text_items']    = '%s prekė(s) - %s';
$_['text_empty']    = 'Jūsų krepšelis yra tuščias!';
$_['text_checkout'] = 'Apmokėti užsakymą';

$_['text_payment_profile'] = 'Mokėjimų profilis';
?>
