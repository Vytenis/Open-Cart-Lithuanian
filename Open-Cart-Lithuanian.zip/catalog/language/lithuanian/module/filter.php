<?php
// Heading
$_['heading_title'] = 'Patikslinti paiešką';
?>