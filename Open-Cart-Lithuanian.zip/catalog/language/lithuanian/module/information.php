<?php
// Heading 
$_['heading_title'] = 'Informacija';

// Text
$_['text_contact']  = 'Kontaktai';
$_['text_sitemap']  = 'Parduotuvės žemėlapis';
?>