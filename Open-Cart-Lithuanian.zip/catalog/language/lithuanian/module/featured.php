<?php
// Heading 
$_['heading_title'] = 'Rekomenduojami';

// Text
$_['text_reviews']  = 'Remiantis %s atsiliepimais(-ų).'; 
?>