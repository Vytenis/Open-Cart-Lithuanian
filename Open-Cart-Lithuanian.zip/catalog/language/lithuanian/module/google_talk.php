<?php
// Heading 
$_['heading_title']  = 'Pagalba gyvai';
?>