<?php
// Heading 
$_['heading_title'] = 'Pasirinkite norimą parduotuvę';

// Text
$_['text_default']  = 'Pagrindinė';
$_['text_store']    = 'Pasirinkite parduotuvę, kurią norite aplankyti.';
?>