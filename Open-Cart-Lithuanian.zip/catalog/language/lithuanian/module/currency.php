<?php
// Text
$_['text_currency'] = 'Valiūta';
?>